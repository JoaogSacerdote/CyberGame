Sobre o HD_02 Citado nas entidades e não nas posições e interações. Se eu botar o HD_02 o jogo vai começar automaticamente com um hd machucado, eu queria que fosse random depois de uma certa quantidade de tempo, então o programa vai pegar o HD_02 E trocar por algum HD_01 dos emcima para deixar machucado. a logica seria mais ou menos essa:
1. Olha qual é a coordenada da vaga "SLOT_SERVIDOR_5" -> (402, 127).
2. Deleta a imagem do "HD_01" que estava desenhada nessa coordenada.
3. Vai no arquivo 'entidades.txt', procura pelo ID "HD_02" para puxar o arquivo de imagem correto.
4. Desenha o "HD_02" exatamente na coordenada (402, 127).

Ou seja, o HD_02 só entra em ação via código, substituindo o HD_01 dentro de uma das posições já mapeadas